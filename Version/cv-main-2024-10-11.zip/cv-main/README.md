
<!-- README.md is generated from README.Rmd. Please edit that file -->

# My Data Driven CV

This repository contains the source files used to build my CV with my
`vitae` package. You can learn more about the vitae package here:
<https://github.com/ropenscilabs/vitae>


[Click here](https://myominnoo.com/) to go to my website. 